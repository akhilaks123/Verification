<?php

namespace App\Http\Controllers;
use App\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function verification(Request $request)
    {
        return view('auth.verification');
    }
    public function postverification(Request $request)
    {
        $user=User::where('token_activation',$request->otp)->first();
        if($user==null){
            return redirect()->back()->withErrors('otp');
        }
        else {
            $user->update([
                'isVerified'=>true,
                'token_activation'=>null]);
            return redirect('login')->withsuccess('Registration successfully completed');
        }
    }
    public function postResend(Request $request)
    {
    $this->validates($request);
    $user = User::where('email',$request->email)->first();
    // event(new VerificationMail($user));
    return redirect()->route('verification')->withsuccess('register','success');

    }
    protected function validates(Request $request)
    {
        $this->validate($request,[
            'email'=>'required|exists|:users,email'],
            [
            'email.exists'=>'hgghvjh'
        ]);
    }
}
