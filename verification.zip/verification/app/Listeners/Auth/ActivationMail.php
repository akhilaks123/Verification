<?php

namespace App\Listeners\Auth;

use App\Events\Auth\VerificationMail;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Mail\Auth\ActivationEmail;
use Mail;
use User;
class ActivationMail
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  VerificationMail  $event
     * @return void
     */
    public function handle(VerificationMail $event)
    {
    if($event->user->isverified){
        return;

    }
    mail::to($event->user->email)->send(new ActivationEmail($event->user));
    }
}
