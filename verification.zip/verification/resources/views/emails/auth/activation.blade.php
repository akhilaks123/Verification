@component('mail::message')
# Activation Email

registration  for otp verification<b> {{$user->token_activation}}</b>


Thanks,<br>
developer
@endcomponent
