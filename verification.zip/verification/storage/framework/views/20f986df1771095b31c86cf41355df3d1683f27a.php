<?php $__env->startComponent('mail::message'); ?>
# Activation Email

registration  for otp verification<b> <?php echo e($user->token_activation); ?></b>


Thanks,<br>
developer
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/akhila/Public/verification/resources/views/emails/auth/activation.blade.php ENDPATH**/ ?>