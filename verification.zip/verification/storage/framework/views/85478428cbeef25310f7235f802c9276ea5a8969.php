<?php if(session('success')): ?>
      <div class="alert-success">
          <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php /**PATH /home/akhila/Public/verification/resources/views/layouts/alert/alert_success.blade.php ENDPATH**/ ?>