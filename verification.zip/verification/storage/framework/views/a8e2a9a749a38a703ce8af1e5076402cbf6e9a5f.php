<?php echo e($slot); ?>

<?php /**PATH /home/akhila/Public/verification/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>